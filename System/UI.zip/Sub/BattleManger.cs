using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleManger : MonoBehaviour
{
    UIManager uiManager;
    //Battle
    GameObject battleMessageCanvas; // ��Ʋ ��Ȳ�� ĵ������ ǥ�����ִ� �뵵
    public Dictionary<string, int> massageDic = new Dictionary<string, int>(); // GetChild�� �������ְ� ����� �ֱ� ���� ���
    public List<GameObject> battleMessages = new List<GameObject>(); // ��Ʋ ĵ���� �ȿ� �ִ� ��ư���� �ν��Ͻ�ȭ �ϱ� ���ؼ� ���

    //BattleSequnce
    public Transform sequnceCanvas;
    //Prefabs
    public GameObject playerTurn;
    public GameObject enemyTurn;
    //ObjectPooling
    public Queue<GameObject> playerQueue = new Queue<GameObject>();
    public Queue<GameObject> enemyQueue = new Queue<GameObject>();
    public int maxCount;
    //MonsterUI
    GameObject playerMonsterUI;
    GameObject enemyMonsterUI;
    TextMeshProUGUI[] monsterNames = new TextMeshProUGUI[2];
    public Image[] monsterHpUI = new Image[2]; // �÷��̾�/�� ������ Hp
    public Image monsterExpUI; // �÷��̾� ������ ����ġ
    public TextMeshProUGUI[] monsterLevel = new TextMeshProUGUI[2]; // �÷��̾�/�� ������ ����
    List<Button> battle = new List<Button>();

    public static bool onBattle;

    private void Awake()
    {
        PlayerWorld.Gobattle += BattleStartEvent;
    }
    void Start()
    {
        uiManager = GameObject.FindGameObjectWithTag("UIManager").GetComponent<UIManager>();
        PlayerWorld.battleOut += BattleEndEvent;
        PlayerBattle.MonsterChange += MonsterChangeOverrideBattle;
        PlayerBattle.MonsterChange += MonsterChangeOverrideUI;
        SetQueue();
    }
    void MonsterChangeOverrideBattle()
    {
        for (int i = 0; i < uiManager.playerInBattle.monsters.Count; i++)
            uiManager.playerInBattle.monsters[i].SetActive(false);
        uiManager.playerInBattle.monsters[uiManager.playerInBattle.equipMonster].SetActive(true);
        Transform playerMonsterPos = GameObject.FindGameObjectWithTag("PlayerMonsterPos").transform;
        uiManager.playerSkills = uiManager.playerMonster.transform.GetChild(0).GetComponent<Skills>();
        uiManager.player.transform.position = playerMonsterPos.position;
    }
    public void BattleStartEvent() // ������ ���� �� �� ����(��������Ʈ)
    {
        #region ��Ʋ UI�� ������
        if (uiManager.itemManager.captureState)
        {
            uiManager.itemManager.CaputreSuccess();
            uiManager.itemManager.captureState = false;
            uiManager.itemManager.captureProgress = false;
            uiManager.playerInWorld.equipMonster = 0;
            return;
        }
        // ��� �ߵ�
        uiManager.battleZone.SetActive(true);
        uiManager.playerMonster = GameObject.FindGameObjectWithTag("PlayerMonster").GetComponent<Monster>();
        uiManager.enemyMonster = GameObject.FindGameObjectWithTag("EnemyMonsterOnBattle").GetComponent<Monster>();
        Time.timeScale = 0.01f;
        Time.fixedDeltaTime = 0.02f * Time.timeScale; // �۾� �� ���� ���� ���� �� 
        sequnceCanvas = GameObject.FindGameObjectWithTag("BattleSequnce").transform;
        playerMonsterUI = GameObject.FindGameObjectWithTag("MonsterUI").transform.GetChild(0).GetChild(0).gameObject;
        enemyMonsterUI = GameObject.FindGameObjectWithTag("MonsterUI").transform.GetChild(0).GetChild(1).gameObject;
        playerMonsterUI.transform.parent.gameObject.SetActive(true); //�÷��̾�, �� ����UI Ȱ��ȭ
        playerMonsterUI.SetActive(true);
        enemyMonsterUI.SetActive(true);
        if (battle.Count <= 0) // �� ���� �ߵ�
        {
            battleMessageCanvas = GameObject.FindGameObjectWithTag("BattleMessageCanvas");
            #region BattleDictionary
            massageDic.Add("OnBattle", 0);
            massageDic.Add("Start", 1);
            massageDic.Add("End", 2);
            massageDic.Add("SkillUse", 3);
            massageDic.Add("AttackState", 4);
            massageDic.Add("PlayerLevelUp", 5);
            massageDic.Add("BattleProgress", 6);
            massageDic.Add("BattleNext", 7);
            massageDic.Add("ItemUseStart", 8);
            #endregion
            for (int i = 0; i < battleMessageCanvas.transform.childCount; i++)
                battle.Add(battleMessageCanvas.transform.GetChild(i).GetComponent<Button>());
            battle[massageDic["OnBattle"]].onClick.AddListener(BattleStart);
            battle[massageDic["Start"]].onClick.AddListener(() => BattleSelect(0)); // ���� ��� 
            battle[massageDic["End"]].onClick.AddListener(BattleExit);
            battle[massageDic["BattleNext"]].onClick.AddListener(uiManager.skillManager.BattleNext);
            battle[massageDic["ItemUseStart"]].onClick.AddListener(() => BattleSelect(1));
            #region BattleCanvas
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["OnBattle"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["Start"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["End"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["SkillUse"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["AttackState"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["PlayerLevelUp"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["BattleProgress"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["BattleNext"]).gameObject);
            battleMessages.Add(battleMessageCanvas.transform.GetChild(massageDic["ItemUseStart"]).gameObject);
            #endregion

            #region MonsterUI
            monsterNames[0] = playerMonsterUI.GetComponentInChildren<TextMeshProUGUI>();
            monsterNames[1] = enemyMonsterUI.GetComponentInChildren<TextMeshProUGUI>();
            monsterHpUI[0] = playerMonsterUI.transform.GetChild(1).GetChild(0).GetComponent<Image>();
            monsterHpUI[1] = enemyMonsterUI.transform.GetChild(1).GetChild(0).GetComponent<Image>();
            monsterExpUI = playerMonsterUI.transform.GetChild(2).GetChild(0).GetComponent<Image>();
            monsterLevel[0] = playerMonsterUI.transform.GetChild(3).GetComponentInChildren<TextMeshProUGUI>();
            monsterLevel[1] = enemyMonsterUI.transform.GetChild(2).GetComponentInChildren<TextMeshProUGUI>();
            #endregion
            
        }
        monsterExpUI.fillAmount = uiManager.playerMonster.exp / uiManager.playerMonster.levelUpExp; // �� ������ �����ָ� �������ڸ���
                                                                                // �ڱ� hp�� exp�� ���缭 õõ�� �����ϰų� ������
        monsterHpUI[0].fillAmount = uiManager.playerMonster.hp / uiManager.playerMonster.maxHp;
        monsterHpUI[1].fillAmount = uiManager.enemyMonster.hp / uiManager.enemyMonster.maxHp;
        monsterNames[0].text = uiManager.playerMonster.monsterName;
        monsterNames[1].text = uiManager.enemyMonster.monsterName;
        monsterLevel[0].text = "Lv " + uiManager.playerMonster.level;
        monsterLevel[1].text = "Lv " + uiManager.enemyMonster.level;
        playerMonsterUI.GetComponent<Image>().color = uiManager.skillManager.skillAttrib[uiManager.playerMonster.
        GetType().Name.Substring(0, 4)];
        enemyMonsterUI.GetComponent<Image>().color = uiManager.skillManager.skillAttrib[uiManager.enemyMonster.
        GetType().Name.Substring(0, 4)];

        uiManager.playerInWorld.gameObject.SetActive(false);
        uiManager.playerInBattle.gameObject.SetActive(true);
        for (int i = 0; i < uiManager.playerInBattle.monsters.Count; i++)
            uiManager.playerInBattle.monsters[i].SetActive(false);
        uiManager.playerInBattle.monsters[uiManager.playerInBattle.equipMonster].SetActive(true);
        uiManager.playerInBattle.monsters[uiManager.playerInBattle.equipMonster].transform.localPosition = new Vector3(0, 0, 0);
        uiManager.playerInBattle.monsters[uiManager.playerInBattle.equipMonster].transform.localScale = new Vector3(1, 1, 1);
        Transform playerMonsterPos = GameObject.FindGameObjectWithTag("PlayerMonsterPos").transform;
        Transform enemyMonsterPos = GameObject.FindGameObjectWithTag("EnemyMonsterPos").transform;
        uiManager.playerSkills = uiManager.playerMonster.transform.GetChild(0).GetComponent<Skills>();
        uiManager.enemySkills = uiManager.enemyMonster.transform.GetChild(0).GetComponent<Skills>();
        uiManager.player.transform.position = playerMonsterPos.position;
        uiManager.enemyMonster.transform.position = enemyMonsterPos.position;
        OnBattle();


    }
    public void BattleEndEvent()
    {
        uiManager.battleZone.SetActive(false);
        uiManager.playerInWorld.gameObject.SetActive(true);
        for (int i = 0; i < uiManager.playerInBattle.monsters.Count; i++)
            uiManager.playerInBattle.monsters[i].SetActive(true);
    }

    void SetQueue()
    {
        for (int i = 0; i < maxCount; i++)
        {
            GameObject player = Instantiate(playerTurn, sequnceCanvas.GetChild(0));
            GameObject enemy = Instantiate(enemyTurn, sequnceCanvas.GetChild(1));
            player.SetActive(false);
            enemy.SetActive(false);
            playerQueue.Enqueue(player);
            enemyQueue.Enqueue(enemy);
        }
    }
    IEnumerator SetSequnce(bool first)
    {
        if (!first) // ó�� �ߵ��ϴ°� �ƴϸ�(������Ʈ�� ���� ���ִ� ������ ��)
        {
            for (int i = 0; i < sequnceCanvas.GetChild(0).childCount; i++)
            {
                sequnceCanvas.GetChild(0).GetChild(i).gameObject.SetActive(false);
                sequnceCanvas.GetChild(1).GetChild(i).gameObject.SetActive(false);
            }
        }
        int playerEndu = uiManager.playerMonster.endurance;
        int enemyEndu = uiManager.enemyMonster.endurance;
        while (true)
        {
            yield return new WaitForSecondsRealtime(0.22f);
            if (playerEndu >= enemyEndu && playerEndu > 0) // ������ ��
            {
                if (playerQueue.Count <= 0) // ť�� ���̻� ������
                    break;
                playerQueue.Peek().SetActive(true);
                playerQueue.Dequeue();
                playerEndu -= uiManager.playerMonster.agility; // ������ - ������
            }
            else if (playerEndu < enemyEndu && enemyEndu > 0)
            {
                if (enemyQueue.Count <= 0)
                    break;
                enemyQueue.Peek().SetActive(true);
                enemyQueue.Dequeue();
                enemyEndu -= uiManager.enemyMonster.agility;
            }
            else
                break;
        }
    }
    //----------------------------------------���� ����----------------------------------------------
    #region MonsterChange
    void MonsterChangeOverrideUI()
    {
        uiManager.playerMonster = GameObject.FindGameObjectWithTag("PlayerMonster").GetComponent<Monster>();
        uiManager.playerSkills = uiManager.playerMonster.gameObject.transform.GetChild(0).GetComponent<Skills>();
    }

    public IEnumerator MonsterChangeCo()
    {
        //�÷��̾��� ��� ������ �������� 0���� ������ 
        bool isLethargy = uiManager.playerInBattle.monsters[0].GetComponent<Monster>().endurance <= 0 &&
        uiManager.playerInBattle.monsters[1].GetComponent<Monster>().endurance <= 0 && uiManager.playerInBattle.monsters[2].GetComponent<Monster>().endurance <= 0;

        yield return new WaitForSecondsRealtime(2);
        battleMessages[massageDic["BattleProgress"]].SetActive(true);
        battleMessages[massageDic["BattleProgress"]].GetComponentInChildren<TextMeshProUGUI>().text =
            uiManager.playerMonster.monsterName + "��(��) �ǿ��� ��� �Ҿ���!";
        yield return new WaitForSecondsRealtime(3);
        if (!isLethargy) //�÷��̾� ������ �������� �� ���� �̻� �̶� 0���� ������ ����
        {
            PlayerBattle.MonsterChange.Invoke(); // ��������Ʈ ����
            battleMessages[massageDic["BattleProgress"]].GetComponentInChildren<TextMeshProUGUI>().text =
                "���� ���Ͱ� �ٽ� ������ ��� ����";
            yield return new WaitForSecondsRealtime(2);
            battleMessages[massageDic["BattleProgress"]].GetComponentInChildren<TextMeshProUGUI>().text =
                uiManager.playerMonster.monsterName + "��(��) �ٽ� ������ �����Ѵ�!";
            yield return new WaitForSecondsRealtime(2);
            battleMessages[massageDic["BattleProgress"]].SetActive(false);
            BattleStart();
        }
        else
        {
            BattleResult(0, 0, false); //�÷��̾��� ��� ������ �������� 0���� ������ �й�
        }
    }
    #endregion
    #region Battle
    // 1�� °
    public void OnBattle()
    {
        //for (int i = 0; i < sequnceCanvas.GetChild(0).childCount; i++) //
        //{
        //    sequnceCanvas.GetChild(0).GetChild(i).gameObject.SetActive(false);
        //    sequnceCanvas.GetChild(1).GetChild(i).gameObject.SetActive(false);
        //}
        battleMessages[massageDic["OnBattle"]].SetActive(true);
        if (uiManager.itemManager.captureProgress) // ������ �������
        {
            battleMessages[massageDic["OnBattle"]].
            GetComponentInChildren<TextMeshProUGUI>().text =
            "��ȹ�� ���� �ߴ�!";
            uiManager.itemManager.captureProgress = false;
        }
        else
            battleMessages[massageDic["OnBattle"]].
            GetComponentInChildren<TextMeshProUGUI>().text =
            " ' " + uiManager.enemyMonster.monsterName + " ' " + "�� �������� ���Դ�!";
    }
    // 2�� ° 
    public void BattleStart() // ���� ���� 
    {
        StartCoroutine(SetSequnce(false));
        battleMessages[massageDic["OnBattle"]].SetActive(false);
        battleMessages[massageDic["Start"]].SetActive(true);
        battleMessages[massageDic["ItemUseStart"]].SetActive(true);
        onBattle = true;
    }

    // 3�� °
    public void BattleSelect(int select) // 0 == �ο�� / 1 == ������ ��� / 2 == �������� 
    {
        if (select == 0) // ���� ����
            uiManager.skillManager.TurnAction(); // ��ų ���
        if (select == 1) // �����ۻ��
            uiManager.itemManager.ItemUse(); // ������ ��� 
        //if (select == 2)
        //    ����
        battleMessages[massageDic["Start"]].SetActive(false);
        battleMessages[massageDic["ItemUseStart"]].SetActive(false);
    }
    public void BattleResult(float getExp, float getMoney, bool match)
    {
        uiManager.playerMonster.Exp += uiManager.enemyMonster.Exp;
        uiManager.playerInWorld.Money += uiManager.enemyMonster.money;
        uiManager.skillManager.monsterEvolution[0] = uiManager.playerMonster.Level == 11 && uiManager.playerMonster.evolution[0];
        uiManager.skillManager.monsterEvolution[1] = uiManager.playerMonster.Level == 11 && uiManager.playerMonster.evolution[1];

        battleMessages[massageDic["BattleProgress"]].SetActive(true);
        if (match) // �¸��ϸ�
        {
            battleMessages[massageDic["BattleProgress"]].GetComponentInChildren<TextMeshProUGUI>().text =
                uiManager.enemyMonster.monsterName + " ��ȭ ����!" + System.Environment.NewLine + "ȹ�� ����ġ : " + getExp.ToString()
                + System.Environment.NewLine + "ȹ���� �� : " + getMoney.ToString();
            if (uiManager.playerMonster.levelUp)
            {
                battleMessages[massageDic["AttackState"]].SetActive(false);
                playerMonsterUI.SetActive(false);
                enemyMonsterUI.SetActive(false);
                monsterLevel[0].text = "Lv " + uiManager.playerMonster.Level;
                monsterLevel[1].text = "Lv " + uiManager.enemyMonster.Level;
                for (int i = 0; i < sequnceCanvas.GetChild(0).childCount; i++) // ���� ����UI ����
                {
                    sequnceCanvas.GetChild(0).GetChild(i).gameObject.SetActive(false);
                    sequnceCanvas.GetChild(1).GetChild(i).gameObject.SetActive(false);
                }
                StartCoroutine(uiManager.skillManager.PlayerMonsterLevelUp());
            }
            else
                StartCoroutine(BattleEndCo());
        }
        else // �й��ϸ�
        {
            battleMessages[massageDic["BattleProgress"]].GetComponentInChildren<TextMeshProUGUI>().text =
                "��ȭ�� ���� �Ͽ����ϴ�!";
            StartCoroutine(BattleEndCo());
        }
    }
    // ���� ��
    public IEnumerator BattleEndCo()
    {
        //playerMonsterUI.transform.parent.gameObject.SetActive(false); //�÷��̾�, �� ����UI Ȱ��ȭ

        battleMessages[massageDic["AttackState"]].SetActive(false);
        enemyMonsterUI.SetActive(false);
        yield return new WaitForSecondsRealtime(uiManager.flowTime * 2);
        for (int i = 0; i < sequnceCanvas.GetChild(0).childCount; i++)
        {
            sequnceCanvas.GetChild(0).GetChild(i).gameObject.SetActive(false);
            sequnceCanvas.GetChild(1).GetChild(i).gameObject.SetActive(false);
        }
        battleMessages[massageDic["BattleProgress"]].SetActive(false);
        battleMessages[massageDic["End"]].SetActive(true);
        battleMessages[massageDic["End"]].GetComponentInChildren<TextMeshProUGUI>().text =
                "���� ������";

    }
    public void BattleExit() // ��Ʋ ���� ���� 
    {
        playerMonsterUI.transform.parent.gameObject.SetActive(false);
        Time.timeScale = 1;
        Time.fixedDeltaTime = 0.02f * Time.timeScale; // �۾� �� ���� ���� ���� �� 
        for (int i = 0; i < sequnceCanvas.GetChild(0).childCount; i++)
        {
            sequnceCanvas.GetChild(0).GetChild(i).gameObject.SetActive(false);
            sequnceCanvas.GetChild(1).GetChild(i).gameObject.SetActive(false);
        }
        battleMessages[massageDic["End"]].SetActive(false);
        battleMessages[massageDic["PlayerLevelUp"]].SetActive(false);
        //�� �κ��� ��ų���� ó���ϴ� �ɷ�
        onBattle = false;
        uiManager.enemyMonster.tag = "EnemyMonster";
        uiManager.enemyMonster.transform.position = uiManager.enemyMonster.monsterWorldPos.transform.position;
        PlayerWorld.battleOut.Invoke();
    }
    #endregion

    //void ActionBack() // �ڷΰ���
    //{
    //    for (int i = 0; i < itemSequence.Count; i++) // ������ ���� �ʱ�ȭ(������ ù ��° �������� ���� ������ �ϱ�����)
    //        itemSequence[i].SetActive(false);
    //    skillListCanvas.transform.GetChild(0).gameObject.SetActive(false);
    //    itemUseCanvas.SetActive(false);
    //    BattleStart();
    //}

    // 6�� °
    public void Battle() // ��ų�� ���� �ϰ� ����
    {
        int playerEndurance = uiManager.playerMonster.endurance;
        int enemyEndurance = uiManager.enemyMonster.endurance;
        bool turnJedge = playerEndurance >= enemyEndurance;
        if (enemyEndurance <= 0)
            uiManager.enemyMonster.endurance = uiManager.enemyMonster.maxEndurance;
        if (uiManager.playerSkills.firstAttack)
            turnJedge = true;
        else if (uiManager.enemySkills.firstAttack)
            turnJedge = false;

        if (turnJedge) // �÷��̾� ������ �������� �� ������ �����º��� ũ��
        {
            uiManager.playerMonster.endurance -= (uiManager.playerMonster.agility - (int)uiManager.playerSkills.buff[(int)BuffList.agility]);
            StartCoroutine(uiManager.skillManager.EnemyUseSkillCo(uiManager.playerMonster.monsterName, uiManager.playerSkills.nameToKorean[uiManager.skillManager.selectSkill]));
            uiManager.playerSkills.UseSkill();
        }
        else // �÷��̾� ������ �������� �� ������ �����º��� ������
        {
            uiManager.enemyMonster.endurance -= (uiManager.enemyMonster.agility - (int)uiManager.enemySkills.buff[(int)BuffList.agility]);
            StartCoroutine(uiManager.skillManager.EnemyUseSkillCo(uiManager.enemyMonster.monsterName, uiManager.enemySkills.nameToKorean[uiManager.skillManager.enemySetSkill]));
            uiManager.enemySkills.UseSkill();
        }
        StartCoroutine(NextTurn(turnJedge));
    }
    public IEnumerator NextTurn(bool judge)
    {
        bool playerturnJedge = uiManager.playerMonster.endurance >= uiManager.enemyMonster.endurance;
        bool enemyturnJedge = uiManager.playerMonster.endurance < uiManager.enemyMonster.endurance; // ���߿� ���� �غ��� �� 
        if (uiManager.enemyMonster.isDead) // �÷��̾ ������ �� ����
        {
            yield return new WaitForSecondsRealtime(uiManager.flowTime);
            BattleResult(uiManager.enemyMonster.exp, uiManager.enemyMonster.money, true); // ���â(UI)�� �����ְ� // ���� �������� ������ ?
            yield break;
        }
        else if (uiManager.playerMonster.isDead)
        {
            yield return new WaitForSecondsRealtime(uiManager.flowTime);
            BattleResult(0, 0, false);
            yield break;
        }
        yield return new WaitForSecondsRealtime(uiManager.flowTime*2); // 3�ʵڿ� ������� ����
        if (judge)
        {
            if (playerturnJedge) // �÷��̾��� �������� �� ũ�� �� �� �� ����
            {
                BattleStart();
                yield break;
            }
            uiManager.enemyMonster.endurance -= (uiManager.enemyMonster.agility - (int)uiManager.enemySkills.buff[(int)BuffList.agility]);
            StartCoroutine(uiManager.skillManager.EnemyUseSkillCo(uiManager.enemyMonster.monsterName, uiManager.enemySkills.nameToKorean[uiManager.skillManager.enemySetSkill]));
            uiManager.enemySkills.UseSkill();
        }
        else
        {
            if (enemyturnJedge) // ���� �������� �� ũ�� �� �� �� ����
            {
                uiManager.enemyMonster.endurance -= (uiManager.enemyMonster.agility - (int)uiManager.enemySkills.buff[(int)BuffList.agility]);
                StartCoroutine(uiManager.skillManager.EnemyUseSkillCo(uiManager.enemyMonster.monsterName, uiManager.enemySkills.nameToKorean[uiManager.skillManager.enemySetSkill]));
                uiManager.enemySkills.UseSkill();
                yield return new WaitForSecondsRealtime(uiManager.flowTime * 2); // 3�ʵڿ� �ٽ� ���� ���� ȭ������
                BattleStart();
                yield break;
            }
            uiManager.playerMonster.endurance -= (uiManager.playerMonster.agility - (int)uiManager.playerSkills.buff[(int)BuffList.agility]);
            StartCoroutine(uiManager.skillManager.EnemyUseSkillCo(uiManager.playerMonster.monsterName, uiManager.playerSkills.nameToKorean[uiManager.skillManager.selectSkill]));
            uiManager.enemySkills.UseSkill();
        }
        if (uiManager.enemyMonster.isDead) // �÷��̾ �İ��� �� ����
        {
            yield return new WaitForSecondsRealtime(uiManager.flowTime);
            BattleResult(uiManager.enemyMonster.exp, uiManager.enemyMonster.money, true);
            yield break;
        }
        else if (uiManager.playerMonster.isDead)
        {
            yield return new WaitForSecondsRealtime(uiManager.flowTime);
            BattleResult(0, 0 ,false);
            yield break;
        }
        if (uiManager.playerMonster.endurance <= 0) // ���� ��� �Һ��ϰ� �� ����
        {
            StartCoroutine(MonsterChangeCo());
            yield break;
        }
        yield return new WaitForSecondsRealtime(uiManager.flowTime*2); // 3�ʵڿ� �ٽ� ���� ���� ȭ������
        BattleStart();
    }
    #endregion
}