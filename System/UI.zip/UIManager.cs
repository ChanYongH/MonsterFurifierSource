using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;
using System.Reflection;

public class UIManager : Singleton<UIManager>
{
    public float flowTime;
    //����
    public GameObject battleZone;
    public GameObject player;
    public PlayerBattle playerInBattle;
    public PlayerWorld playerInWorld;
    public Monster playerMonster;
    public Monster enemyMonster;
    public Skills playerSkills;
    public Skills enemySkills;
    public MonsterInventory monsterInven;
    public ItemInventory itemInven;
    //Ŭ����(�Ŵ�����)
    public BattleManger battleManager; // �ʱ�ȭ ����� �� 
    public ItemManager itemManager;
    public SkillManager skillManager;
    public override void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerInWorld = player.transform.GetChild(0).GetComponent<PlayerWorld>();
        playerInBattle = player.transform.GetChild(1).GetComponent<PlayerBattle>();
        monsterInven = GameObject.FindGameObjectWithTag("Inventory").transform.GetChild(0).GetComponentInChildren<MonsterInventory>();
        battleManager = FindObjectOfType<BattleManger>();
        itemManager = FindObjectOfType<ItemManager>();
        skillManager = FindObjectOfType<SkillManager>();
        PlayerWorld.Gobattle += UIManagerEventStart;
    }
    void UIManagerEventStart()
    {
        playerInWorld = player.transform.GetChild(0).GetComponent<PlayerWorld>();
        playerInBattle = player.transform.GetChild(1).GetComponent<PlayerBattle>();
        monsterInven = GameObject.FindGameObjectWithTag("Inventory").transform.GetChild(0).GetComponentInChildren<MonsterInventory>();
        battleManager = FindObjectOfType<BattleManger>();
        itemManager = FindObjectOfType<ItemManager>();
        skillManager = FindObjectOfType<SkillManager>();
    }
}
